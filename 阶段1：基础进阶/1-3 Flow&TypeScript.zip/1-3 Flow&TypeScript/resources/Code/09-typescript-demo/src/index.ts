let num: number = 100;
// num = "abc";
num = 1000;

function test(a: number, b: number):number {
    return a + b;
}

// let result:string = test(1, 2);