// @flow
// function greet(obj: { sayHello: () => void, name: string }) {
//     obj.sayHello();
// }

// var o = {
//     name: "张学友",
//     sayHello() {
//         console.log("Hello")
//     }
// }

// greet(o);

function ajax(option: {url: string, type: string, success: (data: Object) => void}) {
    
}

// option需要有url参数，还需要有type参数 还需要有success参数

ajax({});