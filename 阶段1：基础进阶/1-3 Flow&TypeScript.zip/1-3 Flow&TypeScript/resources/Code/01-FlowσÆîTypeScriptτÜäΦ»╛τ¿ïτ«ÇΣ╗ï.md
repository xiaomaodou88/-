# Flow和TypeScript课程简介

## 功能
Flow和TypeScript都是用来做JavaScript类型检查的！

## 使用JavaScript进行编程时可能遇到的问题分析

## Flow的使用 

## TypeScript的使用