// 引入css
import './css/index.css'
import './css/b.css'

// 引入less
import './less/index.less'
// 引入sass
import './scss/index.scss'

// 引入bootstrap的css文件
// import 'bootstrap/dist/css/bootstrap.css'